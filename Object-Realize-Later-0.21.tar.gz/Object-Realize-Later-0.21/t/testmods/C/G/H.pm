# Copyrights 2001-2018 by [Mark Overmeer].
#  For other contributors see ChangeLog.
# See the manual pages for details on the licensing terms.
# Pod stripped from pm file by OODoc 2.02.

use warnings;
use strict;

package C::G::H;
use vars '$VERSION';
$VERSION = '0.21';

use base 'C::G';

sub c_g_h() {'c_g_h'}

1;
